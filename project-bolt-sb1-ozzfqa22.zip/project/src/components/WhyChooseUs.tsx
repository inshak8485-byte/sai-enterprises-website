import { Check } from 'lucide-react';

const reasons = [
  'Customized Solutions',
  'Design & Functionality',
  'Quality Materials',
  'Professional Execution',
  'Attention to Detail',
  'Residential & Commercial Expertise',
  'Transparent Communication',
  'Serving Navi Mumbai',
];

export default function WhyChooseUs() {
  return (
    <section id="why-us" className="relative bg-charcoal py-24 lg:py-32">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-br from-gold/10 via-transparent to-transparent" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          {/* Left: heading + image */}
          <div className="reveal">
            <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
              Why Choose Us
            </p>
            <h2 className="font-serif text-4xl font-light leading-tight text-ivory md:text-5xl text-balance">
              WHY SAI ENTERPRISES
            </h2>
            <p className="mt-6 max-w-md text-base font-light leading-relaxed text-ivory/60">
              We don't just design interiors or install roofing — we provide complete
              space transformation solutions. Every project is backed by a commitment
              to quality, transparency, and delivering results that exceed expectations.
            </p>

            <div className="mt-10 overflow-hidden">
              <img
                src="https://images.pexels.com/photos/14613821/pexels-photo-14613821.jpeg?auto=compress&cs=tinysrgb&w=1000"
                alt="Elegant modern staircase interior designed by Sai Enterprises in Navi Mumbai"
                className="h-72 w-full object-cover transition-transform duration-700 hover:scale-105"
              />
            </div>
          </div>

          {/* Right: reasons list */}
          <div className="reveal reveal-delay-2">
            <ul className="space-y-1">
              {reasons.map((reason, idx) => (
                <li
                  key={reason}
                  className="group flex items-center gap-5 border-b border-ivory/10 py-5 transition-colors duration-300 hover:border-gold/40"
                >
                  <span className="font-serif text-2xl font-light text-gold/30 transition-colors duration-300 group-hover:text-gold/60">
                    {String(idx + 1).padStart(2, '0')}
                  </span>
                  <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center border border-gold/30 transition-all duration-300 group-hover:bg-gold">
                    <Check size={14} className="text-gold transition-colors duration-300 group-hover:text-charcoal" />
                  </span>
                  <span className="text-base font-light tracking-wide text-ivory/80 transition-colors duration-300 group-hover:text-ivory">
                    {reason}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
