import { ArrowRight, ArrowDown } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative h-screen w-full overflow-hidden">
      {/* Background image with slow zoom */}
      <div className="absolute inset-0 animate-slow-zoom">
        <img
          src="https://images.pexels.com/photos/7546323/pexels-photo-7546323.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Modern luxury living room interior designed by Sai Enterprises Interior Designing in Navi Mumbai"
          className="h-full w-full object-cover"
        />
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-charcoal/50 via-charcoal/30 to-charcoal/70" />

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-6 text-center">
        <div className="animate-fade-in" style={{ animationDelay: '0.3s', opacity: 0 }}>
          <p className="mb-6 text-xs font-light tracking-[0.4em] text-taupe uppercase">
            Sai Enterprises — Kharghar, Navi Mumbai
          </p>
        </div>

        <h1
          className="animate-fade-up font-serif text-4xl font-light leading-[1.1] text-ivory sm:text-5xl md:text-6xl lg:text-7xl text-balance"
          style={{ animationDelay: '0.5s', opacity: 0 }}
        >
          TRANSFORMING SPACES.
          <br />
          <span className="text-gold">INSIDE &amp; OUT.</span>
        </h1>

        <p
          className="animate-fade-up mt-8 max-w-2xl text-base font-light leading-relaxed text-ivory/80 md:text-lg"
          style={{ animationDelay: '0.8s', opacity: 0 }}
        >
          From beautifully designed interiors to durable roofing and customized
          fabrication solutions, Sai Enterprises helps transform residential and
          commercial spaces across Kharghar and Navi Mumbai.
        </p>

        <div
          className="animate-fade-up mt-10 flex flex-col gap-4 sm:flex-row"
          style={{ animationDelay: '1.1s', opacity: 0 }}
        >
          <a
            href="#services"
            className="group flex items-center justify-center gap-2 border border-gold bg-gold px-8 py-4 text-xs font-medium tracking-widest uppercase text-charcoal transition-all duration-300 hover:bg-transparent hover:text-gold"
          >
            Explore Our Services
            <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
          </a>
          <a
            href="#contact"
            className="group flex items-center justify-center gap-2 border border-ivory/40 px-8 py-4 text-xs font-medium tracking-widest uppercase text-ivory transition-all duration-300 hover:border-gold hover:text-gold"
          >
            Get a Free Consultation
            <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-fade-in" style={{ animationDelay: '1.5s', opacity: 0 }}>
        <div className="flex flex-col items-center gap-2">
          <span className="text-[10px] tracking-[0.3em] text-ivory/60 uppercase">Scroll</span>
          <ArrowDown size={16} className="animate-bounce text-gold" />
        </div>
      </div>
    </section>
  );
}
