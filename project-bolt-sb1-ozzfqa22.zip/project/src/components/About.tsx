import { Check } from 'lucide-react';

const values = [
  'Personalized Design',
  'Quality Craftsmanship',
  'Attention to Detail',
  'Modern Innovation',
  'End-to-End Execution',
];

export default function About() {
  return (
    <section id="about" className="bg-ivory py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          {/* Text side */}
          <div className="reveal">
            <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
              About Us
            </p>
            <h2 className="font-serif text-4xl font-light leading-tight text-charcoal md:text-5xl text-balance">
              ONE TEAM. COMPLETE SPACE SOLUTIONS.
            </h2>
            <div className="mt-8 space-y-5 text-base font-light leading-relaxed text-ink/70">
              <p>
                Sai Enterprises is a Navi Mumbai-based service provider offering
                customized interior designing and roofing solutions for residential
                and commercial spaces. From transforming the interiors of your home
                to creating durable outdoor structures, we focus on practical design,
                quality workmanship and solutions tailored to every client's
                requirements.
              </p>
              <p>
                Whether you need a beautifully designed modular kitchen, a complete
                home interior transformation, or a durable terrace roof shed for
                weather protection, our team brings the same level of care and
                precision to every project across Kharghar and Navi Mumbai.
              </p>
            </div>

            <ul className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {values.map((value) => (
                <li key={value} className="flex items-center gap-3">
                  <span className="flex h-6 w-6 items-center justify-center bg-gold/10">
                    <Check size={14} className="text-gold" />
                  </span>
                  <span className="text-sm font-light tracking-wide text-charcoal">
                    {value}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Image side */}
          <div className="reveal reveal-delay-2 relative">
            <div className="relative overflow-hidden">
              <img
                src="https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Elegant luxury interior space designed by Sai Enterprises Interior Designing in Navi Mumbai"
                className="h-[500px] w-full object-cover transition-transform duration-700 hover:scale-105 lg:h-[600px]"
              />
            </div>
            {/* Decorative frame */}
            <div className="absolute -bottom-4 -right-4 hidden h-32 w-32 border-r border-b border-gold/40 lg:block" />
            <div className="absolute -top-4 -left-4 hidden h-32 w-32 border-l border-t border-gold/40 lg:block" />
          </div>
        </div>
      </div>
    </section>
  );
}
