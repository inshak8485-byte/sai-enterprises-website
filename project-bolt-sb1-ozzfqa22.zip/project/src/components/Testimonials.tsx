import { useState, useEffect } from 'react';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    name: 'Rajesh & Priya Sharma',
    project: 'Interior Design — Kharghar, Navi Mumbai',
    review:
      'Sai Enterprises transformed our 3BHK apartment into a home that feels uniquely ours. The design consultation was thorough, and the team understood exactly what we wanted. The attention to detail in every room was remarkable, and the project was completed on time.',
  },
  {
    name: 'Aditya Mehta',
    project: 'Modular Kitchen — Vashi, Navi Mumbai',
    review:
      'From the first meeting to the final handover, the experience was seamless. The modular kitchen they designed is not just beautiful but incredibly functional for everyday use. The quality of materials and craftsmanship speaks for itself.',
  },
  {
    name: 'Suresh Patil',
    project: 'Terrace Roof Shed — Kharghar, Navi Mumbai',
    review:
      'We needed a terrace shed for weather protection and Sai Enterprises delivered exactly what we needed. The installation was professional, the materials are durable, and the team completed the work on time. Highly recommend for roofing solutions in Navi Mumbai.',
  },
  {
    name: 'Kavita Nair',
    project: 'Commercial Interior — CBD Belapur, Navi Mumbai',
    review:
      'Our office space now reflects the professionalism of our brand. Sai Enterprises balanced aesthetics with functionality perfectly. Communication was transparent throughout, and the timely execution meant we could move in exactly when planned.',
  },
  {
    name: 'Mahesh Deshmukh',
    project: 'Balcony Shed — Seawoods, Navi Mumbai',
    review:
      'The balcony shed they installed has made our space usable year-round. Good quality materials, clean installation work, and the team was respectful of our home throughout. A reliable contractor for shed work in Navi Mumbai.',
  },
  {
    name: 'Sanjay & Anjali Gupta',
    project: 'Full Home Interior — Nerul, Navi Mumbai',
    review:
      'We were nervous about a full home renovation, but Sai Enterprises made the entire process effortless. Their customized interior solutions, transparent communication, and attention to every detail gave us complete confidence. The result takes our breath away every day.',
  },
];

export default function Testimonials() {
  const [active, setActive] = useState(0);

  const next = () => setActive((prev) => (prev + 1) % testimonials.length);
  const prev = () => setActive((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    const interval = setInterval(next, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="testimonials" className="bg-ivory py-24 lg:py-32">
      <div className="mx-auto max-w-5xl px-6 lg:px-10">
        {/* Header */}
        <div className="reveal mb-16 text-center">
          <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
            Testimonials
          </p>
          <h2 className="font-serif text-4xl font-light leading-tight text-charcoal md:text-5xl text-balance">
            DESIGNED WITH TRUST.
            <br />
            REMEMBERED WITH JOY.
          </h2>
          <div className="mx-auto mt-6 h-px w-16 bg-gold/40" />
        </div>

        {/* Testimonial card */}
        <div className="reveal reveal-delay-1 relative">
          {/* Large quote mark */}
          <Quote
            size={80}
            className="absolute -top-6 left-0 text-gold/15"
            fill="currentColor"
          />

          <div className="relative px-6 text-center md:px-16">
            <p className="font-serif text-xl font-light italic leading-relaxed text-charcoal md:text-2xl">
              "{testimonials[active].review}"
            </p>

            <div className="mt-8 flex flex-col items-center gap-1">
              <div className="h-px w-12 bg-gold" />
              <p className="mt-4 text-sm font-medium tracking-wide text-charcoal">
                {testimonials[active].name}
              </p>
              <p className="text-xs font-light tracking-widest uppercase text-gold">
                {testimonials[active].project}
              </p>
            </div>
          </div>

          {/* Navigation */}
          <div className="mt-10 flex items-center justify-center gap-6">
            <button
              onClick={prev}
              className="flex h-10 w-10 items-center justify-center border border-charcoal/20 text-charcoal transition-all duration-300 hover:border-gold hover:bg-gold hover:text-charcoal"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={18} />
            </button>

            {/* Dots */}
            <div className="flex items-center gap-2">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActive(idx)}
                  className={`h-2 transition-all duration-300 ${
                    idx === active ? 'w-8 bg-gold' : 'w-2 bg-charcoal/20'
                  }`}
                  aria-label={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="flex h-10 w-10 items-center justify-center border border-charcoal/20 text-charcoal transition-all duration-300 hover:border-gold hover:bg-gold hover:text-charcoal"
              aria-label="Next testimonial"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
