const steps = [
  {
    number: '01',
    title: 'Consultation',
    description:
      "Understanding the client's vision, requirements, lifestyle, and budget.",
  },
  {
    number: '02',
    title: 'Concept & Planning',
    description: 'Creating design concepts, layouts, and space planning.',
  },
  {
    number: '03',
    title: 'Design Development',
    description:
      'Selecting materials, finishes, furniture, colors, and design elements.',
  },
  {
    number: '04',
    title: 'Execution',
    description:
      'Bringing the design to life with skilled craftsmanship and attention to detail.',
  },
  {
    number: '05',
    title: 'Final Handover',
    description:
      'Delivering a beautifully finished space ready to be experienced.',
  },
];

export default function Process() {
  return (
    <section id="process" className="bg-ivory py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Header */}
        <div className="reveal mb-20 text-center">
          <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
            How We Work
          </p>
          <h2 className="font-serif text-4xl font-light leading-tight text-charcoal md:text-5xl">
            FROM VISION TO REALITY
          </h2>
          <div className="mx-auto mt-6 h-px w-16 bg-gold/40" />
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line for mobile / horizontal line for desktop */}
          <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gold/20 lg:block" />

          <div className="space-y-12 lg:space-y-0">
            {steps.map((step, idx) => (
              <div
                key={step.number}
                className={`reveal reveal-delay-${(idx % 3) + 1} relative flex flex-col gap-6 lg:flex-row lg:items-center ${
                  idx % 2 === 0 ? 'lg:justify-start' : 'lg:justify-end'
                }`}
              >
                <div
                  className={`lg:w-1/2 ${idx % 2 === 0 ? 'lg:pr-16 lg:text-right' : 'lg:pl-16'}`}
                >
                  <div className="group">
                    <span className="font-serif text-6xl font-light text-gold/30 transition-colors duration-500 group-hover:text-gold/60 md:text-7xl">
                      {step.number}
                    </span>
                    <h3 className="mt-2 font-serif text-2xl font-medium text-charcoal">
                      {step.title}
                    </h3>
                    <p className="mt-3 text-sm font-light leading-relaxed text-ink/60">
                      {step.description}
                    </p>
                  </div>
                </div>

                {/* Center dot */}
                <div className="absolute left-1/2 top-4 hidden h-4 w-4 -translate-x-1/2 items-center justify-center lg:flex">
                  <span className="h-3 w-3 rounded-full border border-gold bg-ivory transition-all duration-500 hover:scale-125 hover:bg-gold" />
                </div>

                {/* Spacer for alternating layout */}
                <div className="hidden lg:block lg:w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
