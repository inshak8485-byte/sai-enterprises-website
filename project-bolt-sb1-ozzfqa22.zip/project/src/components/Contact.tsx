import { useState } from 'react';
import { MapPin, Phone, Mail, Instagram, Send, MessageCircle } from 'lucide-react';

const serviceOptions = [
  'Interior Designing',
  'Residential Interior',
  'Commercial Interior',
  'Modular Kitchen',
  'Terrace Shed',
  'Balcony Shed',
  'Parking Shed',
  'Roofing',
  'Custom Fabrication',
  'Other',
];

const whatsappNumber = '919323848485';
const whatsappMessage = encodeURIComponent(
  'Hello Sai Enterprises, I am interested in your services and would like to know more.'
);

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    location: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' });
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name';
    if (!formData.phone.trim()) newErrors.phone = 'Please enter your phone number';
    else if (!/^[+]?[\d\s-]{8,}$/.test(formData.phone))
      newErrors.phone = 'Please enter a valid phone number';
    if (!formData.email.trim()) newErrors.email = 'Please enter your email address';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = 'Please enter a valid email address';
    if (!formData.service) newErrors.service = 'Please select a service';
    if (!formData.message.trim()) newErrors.message = 'Please enter a message';
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    setSubmitted(true);
    setFormData({ name: '', phone: '', email: '', service: '', location: '', message: '' });
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="contact" className="bg-ivory py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Header */}
        <div className="reveal mb-16 text-center">
          <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
            Get in Touch
          </p>
          <h2 className="font-serif text-4xl font-light leading-tight text-charcoal md:text-5xl">
            LET'S TRANSFORM YOUR SPACE
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-base font-light leading-relaxed text-ink/60">
            Whether you're planning a new interior or need a customized roofing
            solution, we're here to help.
          </p>
          <div className="mx-auto mt-6 h-px w-16 bg-gold/40" />
        </div>

        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left: contact info */}
          <div className="reveal space-y-8">
            <div>
              <h3 className="font-serif text-2xl font-medium text-charcoal">
                Let's Discuss Your Project
              </h3>
              <p className="mt-3 text-sm font-light leading-relaxed text-ink/60">
                Tell us about your project and our team will get in touch to discuss
                how we can bring your vision to life. Based in Kharghar, serving
                clients across Navi Mumbai and surrounding areas.
              </p>
            </div>

            <div className="space-y-5">
              <div className="group flex items-start gap-4">
                <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center border border-gold/30 transition-colors duration-300 group-hover:bg-gold">
                  <Phone size={16} className="text-gold transition-colors duration-300 group-hover:text-charcoal" />
                </span>
                <div>
                  <p className="text-[10px] font-light tracking-[0.2em] uppercase text-gold">Phone</p>
                  <div className="flex flex-col gap-0.5">
                    <a
                      href="tel:+919323848485"
                      className="text-sm font-light text-charcoal transition-colors hover:text-gold"
                    >
                      +91 9323848485
                    </a>
                    <a
                      href="tel:+919167341491"
                      className="text-sm font-light text-charcoal transition-colors hover:text-gold"
                    >
                      +91 91673 41491
                    </a>
                  </div>
                </div>
              </div>

              <div className="group flex items-start gap-4">
                <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center border border-gold/30 transition-colors duration-300 group-hover:bg-gold">
                  <Mail size={16} className="text-gold transition-colors duration-300 group-hover:text-charcoal" />
                </span>
                <div>
                  <p className="text-[10px] font-light tracking-[0.2em] uppercase text-gold">Email</p>
                  <p className="text-sm font-light text-charcoal">[Official Email Address]</p>
                </div>
              </div>

              <div className="group flex items-start gap-4">
                <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center border border-gold/30 transition-colors duration-300 group-hover:bg-gold">
                  <MapPin size={16} className="text-gold transition-colors duration-300 group-hover:text-charcoal" />
                </span>
                <div>
                  <p className="text-[10px] font-light tracking-[0.2em] uppercase text-gold">Location</p>
                  <a
                    href="https://share.google/KytbfkFnVMtqBb572"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-light text-charcoal transition-colors hover:text-gold"
                  >
                    Kharghar, Navi Mumbai, Maharashtra
                  </a>
                </div>
              </div>

              <div className="group flex items-start gap-4">
                <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center border border-gold/30 transition-colors duration-300 group-hover:bg-gold">
                  <Instagram size={16} className="text-gold transition-colors duration-300 group-hover:text-charcoal" />
                </span>
                <div>
                  <p className="text-[10px] font-light tracking-[0.2em] uppercase text-gold">Instagram</p>
                  <p className="text-sm font-light text-charcoal">@saienterprises.interiors</p>
                </div>
              </div>
            </div>

            {/* WhatsApp button */}
            <a
              href={`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-3 bg-[#25D366] px-6 py-4 text-xs font-medium tracking-widest uppercase text-white transition-all duration-300 hover:bg-[#1da851]"
            >
              <MessageCircle size={16} />
              Chat on WhatsApp
            </a>
          </div>

          {/* Right: form */}
          <div className="reveal reveal-delay-2">
            <form
              onSubmit={handleSubmit}
              noValidate
              className="space-y-6 border border-gold/20 bg-white p-8 lg:p-10"
            >
              <div>
                <label className="mb-2 block text-[10px] font-light tracking-[0.2em] uppercase text-gold">
                  Full Name <span className="text-gold/60">*</span>
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full border-b border-charcoal/20 bg-transparent py-3 text-sm font-light text-charcoal outline-none transition-colors focus:border-gold"
                  placeholder="Your full name"
                />
                {errors.name && (
                  <p className="mt-1 text-xs font-light text-gold">{errors.name}</p>
                )}
              </div>

              <div className="grid gap-6 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-[10px] font-light tracking-[0.2em] uppercase text-gold">
                    Phone Number <span className="text-gold/60">*</span>
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full border-b border-charcoal/20 bg-transparent py-3 text-sm font-light text-charcoal outline-none transition-colors focus:border-gold"
placeholder="+91 9323848485 / 91673 41491"
                  />
                  {errors.phone && (
                    <p className="mt-1 text-xs font-light text-gold">{errors.phone}</p>
                  )}
                </div>
                <div>
                  <label className="mb-2 block text-[10px] font-light tracking-[0.2em] uppercase text-gold">
                    Email Address <span className="text-gold/60">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full border-b border-charcoal/20 bg-transparent py-3 text-sm font-light text-charcoal outline-none focus:border-gold"
                    placeholder="you@example.com"
                  />
                  {errors.email && (
                    <p className="mt-1 text-xs font-light text-gold">{errors.email}</p>
                  )}
                </div>
              </div>

              <div className="grid gap-6 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-[10px] font-light tracking-[0.2em] uppercase text-gold">
                    Service Interested In <span className="text-gold/60">*</span>
                  </label>
                  <select
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    required
                    className="w-full border-b border-charcoal/20 bg-transparent py-3 text-sm font-light text-charcoal outline-none transition-colors focus:border-gold"
                  >
                    <option value="">Select a service</option>
                    {serviceOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                  {errors.service && (
                    <p className="mt-1 text-xs font-light text-gold">{errors.service}</p>
                  )}
                </div>
                <div>
                  <label className="mb-2 block text-[10px] font-light tracking-[0.2em] uppercase text-gold">
                    Project Location
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    className="w-full border-b border-charcoal/20 bg-transparent py-3 text-sm font-light text-charcoal outline-none transition-colors focus:border-gold"
                    placeholder="e.g. Kharghar, Vashi, Panvel"
                  />
                </div>
              </div>

              <div>
                <label className="mb-2 block text-[10px] font-light tracking-[0.2em] uppercase text-gold">
                  Message <span className="text-gold/60">*</span>
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={4}
                  className="w-full resize-none border-b border-charcoal/20 bg-transparent py-3 text-sm font-light text-charcoal outline-none transition-colors focus:border-gold"
                  placeholder="Tell us about your space and what you need..."
                />
                {errors.message && (
                  <p className="mt-1 text-xs font-light text-gold">{errors.message}</p>
                )}
              </div>

              <button
                type="submit"
                className="group flex w-full items-center justify-center gap-2 bg-charcoal py-4 text-xs font-medium tracking-widest uppercase text-ivory transition-all duration-300 hover:bg-gold hover:text-charcoal"
              >
                {submitted ? 'Message Sent — Thank You!' : 'Send Message'}
                {!submitted && <Send size={14} className="transition-transform group-hover:translate-x-1" />}
              </button>

              {submitted && (
                <p className="text-center text-sm font-light text-gold">
                  We'll get back to you within 24 hours.
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
