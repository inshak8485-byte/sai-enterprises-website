import { Instagram, Facebook, Linkedin, Phone, Mail, MapPin } from 'lucide-react';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About Us', href: '#about' },
  { label: 'Interior Designing', href: '#interior-services' },
  { label: 'Roofing & Sheds', href: '#roofing-services' },
  { label: 'Our Projects', href: '#projects' },
  { label: 'Why Choose Us', href: '#why-us' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
];

export default function Footer() {
  return (
    <footer className="bg-charcoal text-ivory">
      {/* Main footer */}
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid gap-12 md:grid-cols-3 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <h3 className="font-serif text-2xl font-medium text-ivory">SAI ENTERPRISES</h3>
            <p className="mt-1 text-[10px] font-light tracking-[0.3em] uppercase text-gold">
              Interiors &amp; Roofing
            </p>
            <p className="mt-5 max-w-xs text-sm font-light leading-relaxed text-ivory/50">
              Complete space transformation solutions — from premium interior
              designing to durable roofing and custom fabrication in Kharghar and
              Navi Mumbai.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="mb-5 text-[10px] font-light tracking-[0.2em] uppercase text-gold">
              Navigation
            </h4>
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm font-light text-ivory/60 transition-colors duration-300 hover:text-gold"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="mb-5 text-[10px] font-light tracking-[0.2em] uppercase text-gold">
              Contact
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm font-light text-ivory/60">
                <Phone size={14} className="mt-0.5 flex-shrink-0 text-gold" />
                <div className="flex flex-col gap-0.5">
                  <a href="tel:+919323848485" className="transition-colors hover:text-gold">
                    +91 9323848485
                  </a>
                  <a href="tel:+919167341491" className="transition-colors hover:text-gold">
                    +91 91673 41491
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3 text-sm font-light text-ivory/60">
                <Mail size={14} className="mt-0.5 flex-shrink-0 text-gold" />
                [Official Email Address]
              </li>
              <li className="flex items-start gap-3 text-sm font-light text-ivory/60">
                <MapPin size={14} className="mt-0.5 flex-shrink-0 text-gold" />
                <a
                  href="https://share.google/KytbfkFnVMtqBb572"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition-colors hover:text-gold"
                >
                  Kharghar, Navi Mumbai,<br />Maharashtra
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="mb-5 text-[10px] font-light tracking-[0.2em] uppercase text-gold">
              Follow Us
            </h4>
            <div className="flex gap-3">
              <a
                href="#"
                className="flex h-10 w-10 items-center justify-center border border-ivory/20 transition-all duration-300 hover:border-gold hover:bg-gold"
                aria-label="Instagram"
              >
                <Instagram size={16} className="text-ivory/60 transition-colors duration-300 hover:text-charcoal" />
              </a>
              <a
                href="#"
                className="flex h-10 w-10 items-center justify-center border border-ivory/20 transition-all duration-300 hover:border-gold hover:bg-gold"
                aria-label="Facebook"
              >
                <Facebook size={16} className="text-ivory/60 transition-colors duration-300 hover:text-charcoal" />
              </a>
              <a
                href="#"
                className="flex h-10 w-10 items-center justify-center border border-ivory/20 transition-all duration-300 hover:border-gold hover:bg-gold"
                aria-label="LinkedIn"
              >
                <Linkedin size={16} className="text-ivory/60 transition-colors duration-300 hover:text-charcoal" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-ivory/10">
        <div className="mx-auto max-w-7xl px-6 py-6 lg:px-10">
          <p className="text-center text-xs font-light tracking-wide text-ivory/40">
            © 2026 Sai Enterprises Interior Designing. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
