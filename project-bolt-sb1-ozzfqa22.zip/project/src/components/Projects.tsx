import { useState } from 'react';
import { ArrowRight } from 'lucide-react';

type Project = {
  name: string;
  category: string;
  location: string;
  image: string;
  alt: string;
  filter: string;
};

const projects: Project[] = [
  {
    name: 'The Ivory Residence',
    category: 'Interior Designing',
    location: 'Kharghar, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/34688219/pexels-photo-34688219.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Residential interior design project in Kharghar, Navi Mumbai by Sai Enterprises',
    filter: 'Interior Designing',
  },
  {
    name: 'Lumière Living',
    category: 'Residential',
    location: 'Vashi, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/33529500/pexels-photo-33529500.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Luxury living room interior design in Vashi, Navi Mumbai',
    filter: 'Residential',
  },
  {
    name: 'Serenity Suite',
    category: 'Residential',
    location: 'Belapur, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/7546276/pexels-photo-7546276.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Premium bedroom interior design in Belapur, Navi Mumbai by Sai Enterprises',
    filter: 'Residential',
  },
  {
    name: 'Culinary Canvas',
    category: 'Interior Designing',
    location: 'Nerul, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/7148841/pexels-photo-7148841.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Customized modular kitchen interior design in Nerul, Navi Mumbai',
    filter: 'Interior Designing',
  },
  {
    name: 'The Corporate Canvas',
    category: 'Commercial',
    location: 'CBD Belapur, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/164586/pexels-photo-164586.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Commercial office interior design in CBD Belapur, Navi Mumbai',
    filter: 'Commercial',
  },
  {
    name: 'Terrace Shield',
    category: 'Terrace Sheds',
    location: 'Kharghar, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/12549434/pexels-photo-12549434.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Terrace roof shed installation by Sai Enterprises in Kharghar, Navi Mumbai',
    filter: 'Terrace Sheds',
  },
  {
    name: 'Balcony Haven',
    category: 'Balcony Sheds',
    location: 'Seawoods, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/15459714/pexels-photo-15459714.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Modern balcony roofing solution in Seawoods, Navi Mumbai',
    filter: 'Balcony Sheds',
  },
  {
    name: 'Parking Canopy',
    category: 'Roofing',
    location: 'Airoli, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/33459821/pexels-photo-33459821.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Parking shed and roofing solution in Airoli, Navi Mumbai by Sai Enterprises',
    filter: 'Roofing',
  },
  {
    name: 'Steel & Glass Structure',
    category: 'Roofing',
    location: 'Panvel, Navi Mumbai',
    image:
      'https://images.pexels.com/photos/36573751/pexels-photo-36573751.jpeg?auto=compress&cs=tinysrgb&w=1000',
    alt: 'Custom metal fabrication and roofing structure in Panvel, Navi Mumbai',
    filter: 'Roofing',
  },
];

const categories = ['All Projects', 'Interior Designing', 'Residential', 'Commercial', 'Terrace Sheds', 'Balcony Sheds', 'Roofing'];

export default function Projects() {
  const [activeCategory, setActiveCategory] = useState('All Projects');

  const filtered =
    activeCategory === 'All Projects'
      ? projects
      : projects.filter((p) => p.filter === activeCategory);

  return (
    <section id="projects" className="bg-charcoal py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Header */}
        <div className="reveal mb-12 text-center">
          <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
            Portfolio
          </p>
          <h2 className="font-serif text-4xl font-light leading-tight text-ivory md:text-5xl">
            OUR WORK
          </h2>
          <div className="mx-auto mt-6 h-px w-16 bg-gold/40" />
          <p className="mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-ivory/50">
            A selection of interior design and roofing projects completed across
            Kharghar and Navi Mumbai. Project images will be updated as they become
            available.
          </p>
        </div>

        {/* Category filter */}
        <div className="reveal reveal-delay-1 mb-12 flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 text-xs font-light tracking-widest uppercase transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-gold text-charcoal'
                  : 'text-ivory/60 hover:text-gold'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Masonry grid */}
        <div className="columns-1 gap-6 sm:columns-2 lg:columns-3 [&>*]:mb-6">
          {filtered.map((project, idx) => (
            <div
              key={project.name}
              className={`reveal reveal-delay-${(idx % 3) + 1} group relative overflow-hidden break-inside-avoid`}
            >
              <img
                src={project.image}
                alt={project.alt}
                className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              {/* Overlay */}
              <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-charcoal/90 via-charcoal/20 to-transparent p-6 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                <span className="text-[10px] font-light tracking-[0.3em] text-gold uppercase">
                  {project.category}
                </span>
                <h3 className="mt-2 font-serif text-xl font-medium text-ivory">
                  {project.name}
                </h3>
                <p className="mt-1 text-xs font-light text-ivory/60">{project.location}</p>
              </div>
              {/* Always visible label (bottom) */}
              <div className="absolute bottom-0 left-0 right-0 flex items-end justify-between p-5 transition-opacity duration-500 group-hover:opacity-0">
                <div>
                  <h3 className="font-serif text-lg font-medium text-ivory drop-shadow-lg">
                    {project.name}
                  </h3>
                  <p className="text-xs font-light text-ivory/70">{project.location}</p>
                </div>
                <span className="text-[10px] font-light tracking-[0.2em] text-gold uppercase">
                  {project.category}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="reveal mt-14 text-center">
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 border border-gold px-10 py-4 text-xs font-medium tracking-widest uppercase text-gold transition-all duration-300 hover:bg-gold hover:text-charcoal"
          >
            Start Your Project
            <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
          </a>
        </div>
      </div>
    </section>
  );
}
