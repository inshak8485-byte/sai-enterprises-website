import { Home, Sofa, BedDouble, UtensilsCrossed, Building2, Hammer, ArrowRight, Layers, Shield, Warehouse, Sun, Wrench, Factory } from 'lucide-react';

const interiorServices = [
  { icon: Home, label: 'Residential Interiors' },
  { icon: Sofa, label: 'Living Room Interiors' },
  { icon: BedDouble, label: 'Bedroom Design' },
  { icon: UtensilsCrossed, label: 'Modular Kitchens' },
  { icon: Building2, label: 'Office Interiors' },
  { icon: Layers, label: 'Commercial Interiors' },
  { icon: Hammer, label: 'Renovation & Space Transformation' },
];

const roofingServices = [
  { icon: Sun, label: 'Terrace Roof Sheds' },
  { icon: Shield, label: 'Balcony Sheds' },
  { icon: Warehouse, label: 'Parking Sheds' },
  { icon: Layers, label: 'Polycarbonate Roofing' },
  { icon: Wrench, label: 'Custom Metal Fabrication' },
  { icon: Factory, label: 'Commercial Roofing Solutions' },
];

export default function Services() {
  return (
    <section id="services" className="bg-ivory py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Header */}
        <div className="reveal mb-20 text-center">
          <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
            What We Do
          </p>
          <h2 className="font-serif text-4xl font-light leading-tight text-charcoal md:text-5xl">
            OUR EXPERTISE
          </h2>
          <div className="mx-auto mt-6 h-px w-16 bg-gold/40" />
          <p className="mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-ink/60">
            Sai Enterprises offers two core service divisions — interior designing and
            roofing solutions — providing complete space transformation for residential
            and commercial properties across Navi Mumbai.
          </p>
        </div>

        {/* Division 01: Interior Designing */}
        <div id="interior-services" className="reveal mb-20 scroll-mt-24">
          <div className="grid items-stretch gap-10 lg:grid-cols-2 lg:gap-16">
            {/* Image */}
            <div className="relative overflow-hidden">
              <img
                src="https://images.pexels.com/photos/27164969/pexels-photo-27164969.jpeg?auto=compress&cs=tinysrgb&w=1000"
                alt="Modern living room interior design by Sai Enterprises in Navi Mumbai"
                className="h-full min-h-[400px] w-full object-cover transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute top-6 left-6 bg-charcoal/80 px-5 py-3 backdrop-blur-sm">
                <span className="font-serif text-sm font-medium tracking-widest text-gold uppercase">
                  Division 01
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="flex flex-col justify-center">
              <p className="mb-3 text-xs font-light tracking-[0.3em] text-gold uppercase">
                Interior Designing
              </p>
              <h3 className="font-serif text-3xl font-light leading-tight text-charcoal md:text-4xl">
                INTERIOR DESIGNING
              </h3>
              <p className="mt-5 text-base font-light leading-relaxed text-ink/70">
                Thoughtfully designed interiors that combine aesthetics, functionality
                and comfort. Whether it's a home, office or commercial space, our
                interior design services in Navi Mumbai are tailored to your lifestyle
                and vision.
              </p>

              <ul className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {interiorServices.map((service) => {
                  const Icon = service.icon;
                  return (
                    <li key={service.label} className="flex items-center gap-3">
                      <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center border border-gold/30 transition-colors duration-300 hover:bg-gold">
                        <Icon size={15} className="text-gold transition-colors duration-300 hover:text-charcoal" />
                      </span>
                      <span className="text-sm font-light tracking-wide text-charcoal">
                        {service.label}
                      </span>
                    </li>
                  );
                })}
              </ul>

              <a
                href="#projects"
                className="group mt-8 inline-flex w-fit items-center gap-2 border border-gold px-7 py-3.5 text-xs font-medium tracking-widest uppercase text-gold transition-all duration-300 hover:bg-gold hover:text-charcoal"
              >
                Explore Interior Services
                <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </div>

        {/* Division 02: Roofing & Shed Solutions */}
        <div id="roofing-services" className="reveal scroll-mt-24">
          <div className="grid items-stretch gap-10 lg:grid-cols-2 lg:gap-16">
            {/* Content (left on desktop) */}
            <div className="flex flex-col justify-center order-2 lg:order-1">
              <p className="mb-3 text-xs font-light tracking-[0.3em] text-gold uppercase">
                Roofing &amp; Sheds
              </p>
              <h3 className="font-serif text-3xl font-light leading-tight text-charcoal md:text-4xl">
                ROOFING &amp; SHED SOLUTIONS
              </h3>
              <p className="mt-5 text-base font-light leading-relaxed text-ink/70">
                Durable and customized roofing solutions designed to protect and
                enhance your space. From terrace sheds to custom fabrication, our
                roofing services in Kharghar and Navi Mumbai are built to last.
              </p>

              <ul className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {roofingServices.map((service) => {
                  const Icon = service.icon;
                  return (
                    <li key={service.label} className="flex items-center gap-3">
                      <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center border border-gold/30 transition-colors duration-300 hover:bg-gold">
                        <Icon size={15} className="text-gold transition-colors duration-300 hover:text-charcoal" />
                      </span>
                      <span className="text-sm font-light tracking-wide text-charcoal">
                        {service.label}
                      </span>
                    </li>
                  );
                })}
              </ul>

              <a
                href="#projects"
                className="group mt-8 inline-flex w-fit items-center gap-2 border border-gold px-7 py-3.5 text-xs font-medium tracking-widest uppercase text-gold transition-all duration-300 hover:bg-gold hover:text-charcoal"
              >
                Explore Roofing Services
                <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
              </a>
            </div>

            {/* Image (right on desktop) */}
            <div className="relative overflow-hidden order-1 lg:order-2">
              <img
                src="https://images.pexels.com/photos/12549434/pexels-photo-12549434.jpeg?auto=compress&cs=tinysrgb&w=1000"
                alt="Modern metal canopy and roofing structure installation by Sai Enterprises in Navi Mumbai"
                className="h-full min-h-[400px] w-full object-cover transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute top-6 right-6 bg-charcoal/80 px-5 py-3 backdrop-blur-sm">
                <span className="font-serif text-sm font-medium tracking-widest text-gold uppercase">
                  Division 02
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
