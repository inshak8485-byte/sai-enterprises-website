import { ArrowRight, Phone } from 'lucide-react';

export default function CTA() {
  return (
    <section className="relative overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Luxury interior design space by Sai Enterprises Interior Designing in Navi Mumbai"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-6 py-24 text-center lg:py-36">
        <div className="reveal">
          <p className="mb-4 text-xs font-light tracking-[0.3em] text-gold uppercase">
            Let's Begin
          </p>
          <h2 className="font-serif text-4xl font-light leading-tight text-ivory md:text-6xl text-balance">
            LET'S CREATE SOMETHING
            <br />
            <span className="text-gold">EXTRAORDINARY.</span>
          </h2>
          <p className="mx-auto mt-8 max-w-xl text-base font-light leading-relaxed text-ivory/70">
            Have a space in mind? Whether it's an interior transformation or a
            roofing solution, let's turn your vision into reality.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href="#contact"
              className="group flex items-center gap-2 bg-gold px-8 py-4 text-xs font-medium tracking-widest uppercase text-charcoal transition-all duration-300 hover:bg-gold-dark"
            >
              Start Your Project
              <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="tel:+919323848485"
              className="group flex items-center gap-2 border border-ivory/40 px-8 py-4 text-xs font-medium tracking-widest uppercase text-ivory transition-all duration-300 hover:border-gold hover:text-gold"
            >
              <Phone size={14} />
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
