import { MessageCircle } from 'lucide-react';

const whatsappNumber = '919323848485';
const whatsappMessage = encodeURIComponent(
  'Hello Sai Enterprises, I am interested in your services and would like to know more.'
);

export default function WhatsAppButton() {
  return (
    <a
      href={`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`}
      target="_blank"
      rel="noopener noreferrer"
      className="group fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center bg-[#25D366] shadow-lg transition-all duration-300 hover:scale-110 hover:bg-[#1da851]"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={26} className="text-white" />
      {/* Pulse ring */}
      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#25D366] opacity-20" />
    </a>
  );
}
