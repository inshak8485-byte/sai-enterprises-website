import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About Us', href: '#about' },
  { label: 'Interior Designing', href: '#interior-services' },
  { label: 'Roofing & Sheds', href: '#roofing-services' },
  { label: 'Our Projects', href: '#projects' },
  { label: 'Why Choose Us', href: '#why-us' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-ivory/95 backdrop-blur-md py-3 shadow-[0_1px_0_0_rgba(184,155,94,0.2)]'
          : 'bg-transparent py-6'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 lg:px-10">
        <a href="#home" className="flex flex-col leading-none">
          <span
            className={`font-serif text-xl font-medium tracking-wide transition-colors duration-500 ${
              scrolled ? 'text-charcoal' : 'text-ivory'
            }`}
          >
            SAI ENTERPRISES
          </span>
          <span
            className={`text-[10px] font-light tracking-[0.3em] transition-colors duration-500 ${
              scrolled ? 'text-gold' : 'text-taupe'
            }`}
          >
            INTERIORS &amp; ROOFING
          </span>
        </a>

        <ul className="hidden items-center gap-6 xl:flex">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className={`text-[11px] font-light tracking-widest uppercase transition-colors duration-300 hover:text-gold ${
                  scrolled ? 'text-charcoal' : 'text-ivory/90'
                }`}
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <button
          className={`lg:hidden ${scrolled ? 'text-charcoal' : 'text-ivory'}`}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-all duration-500 lg:hidden ${
          menuOpen ? 'max-h-screen' : 'max-h-0'
        }`}
      >
        <ul className="flex flex-col gap-1 bg-ivory px-6 py-6">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="block py-3 text-sm font-light tracking-widest uppercase text-charcoal transition-colors hover:text-gold"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}
